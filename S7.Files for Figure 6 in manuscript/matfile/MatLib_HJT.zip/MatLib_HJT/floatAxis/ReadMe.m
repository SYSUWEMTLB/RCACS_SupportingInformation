The floatAxisX m-file enables you to plot parameters with different units 
(eg. temperature, salinity and density versus depth) on the same axes having
the x-axis for the parameters "floating" below. FloatAxisY plots floating 
axes on the left-hand side of the plot. The number of parameters plotted is 
not limited. 

Type ctdplotx or ctdploty at the Matlab command prompt for a demo.