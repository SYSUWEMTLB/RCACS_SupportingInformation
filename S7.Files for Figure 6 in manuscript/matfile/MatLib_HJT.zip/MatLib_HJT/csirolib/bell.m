% BELL       Makes a bell noise and no carriage return.

fprintf('');
