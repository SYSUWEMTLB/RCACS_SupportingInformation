orient('portrait')
set(gcf,'units','inches','position',[4.1 .1 8.0 8.9]);
set( gcf, 'paperunits', 'inches', 'paperposition', [.25 1.5 8 8.9] );
